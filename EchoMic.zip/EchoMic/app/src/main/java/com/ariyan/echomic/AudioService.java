package com.ariyan.echomic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;

public class AudioService extends Service {
    static final int SR = 44100;
    public static volatile boolean running = false;
    public static volatile float micGain = 1.0f;    // 0..3
    public static volatile float echoMix = 0.35f;   // 0..1
    public static volatile float echoFb = 0.30f;    // 0..0.8
    public static volatile float echoSec = 0.25f;   // 0.05..0.6
    public static volatile float musicVol = 0.8f;   // 0..1
    public static MediaPlayer mp;

    private Thread thread;

    public static void loadMusic(Context c, Uri uri) throws Exception {
        if (mp != null) { try { mp.release(); } catch (Exception ignored) {} }
        mp = new MediaPlayer();
        mp.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
        mp.setDataSource(c.getApplicationContext(), uri);
        mp.prepare();
        mp.setVolume(musicVol, musicVol);
    }

    public static boolean toggleMusic() {
        if (mp == null) return false;
        if (mp.isPlaying()) mp.pause(); else mp.start();
        return mp.isPlaying();
    }

    public static void applyMusicVol() {
        if (mp != null) { try { mp.setVolume(musicVol, musicVol); } catch (Exception ignored) {} }
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("echo", "Echo Mic", NotificationManager.IMPORTANCE_LOW));
        Notification n = new Notification.Builder(this, "echo")
                .setContentTitle("Echo Mic চালু আছে")
                .setContentText("মাইক + ইকো + মিউজিক চলছে")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(1, n);
        }
        if (!running) {
            running = true;
            thread = new Thread(this::loop, "echo-loop");
            thread.start();
        }
        return START_NOT_STICKY;
    }

    private void loop() {
        AudioRecord rec = null;
        AudioTrack track = null;
        AcousticEchoCanceler aec = null;
        try {
            int minRec = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            rec = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(minRec, 4096) * 2);
            if (AcousticEchoCanceler.isAvailable()) {
                aec = AcousticEchoCanceler.create(rec.getAudioSessionId());
                if (aec != null) aec.setEnabled(true);
            }
            int minTrack = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SR)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(minTrack, 2048) * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                    .build();

            float[] delay = new float[SR + 10];
            int w = 0;
            short[] buf = new short[1024];
            rec.startRecording();
            track.play();
            while (running) {
                int r = rec.read(buf, 0, buf.length);
                if (r <= 0) continue;
                int d = (int) (echoSec * SR);
                if (d < 1) d = 1;
                if (d > SR) d = SR;
                float g = micGain, fb = echoFb, mix = echoMix;
                for (int i = 0; i < r; i++) {
                    float x = buf[i] / 32768f * g;
                    int rp = w - d;
                    if (rp < 0) rp += delay.length;
                    float e = delay[rp];
                    float in = x + e * fb;
                    if (in > 1f) in = 1f; else if (in < -1f) in = -1f;
                    delay[w] = in;
                    if (++w >= delay.length) w = 0;
                    float out = x + e * mix;
                    if (out > 1f) out = 1f; else if (out < -1f) out = -1f;
                    buf[i] = (short) (out * 32767f);
                }
                track.write(buf, 0, r);
            }
        } catch (Throwable t) {
            // ignore; service stops below
        } finally {
            running = false;
            try { if (rec != null) { rec.stop(); rec.release(); } } catch (Exception ignored) {}
            try { if (track != null) { track.stop(); track.release(); } } catch (Exception ignored) {}
            try { if (aec != null) aec.release(); } catch (Exception ignored) {}
            stopSelf();
        }
    }

    @Override public void onDestroy() {
        running = false;
        super.onDestroy();
    }
}
