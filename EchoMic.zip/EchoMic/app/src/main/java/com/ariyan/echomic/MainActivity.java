package com.ariyan.echomic;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.function.IntConsumer;

public class MainActivity extends Activity {
    static final int REQ_PERM = 1, REQ_SONG = 2;
    LinearLayout root;
    TextView status;
    Button startBtn, playBtn;
    final Handler h = new Handler(Looper.getMainLooper());

    int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#0f1115"));
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(36), dp(16), dp(40));
        sv.addView(root);
        setContentView(sv);

        text("🎤 Echo Mic - মিউজিক কার্ড", 22, Color.WHITE, Gravity.CENTER);
        text("মেসেঞ্জার কলে স্পিকার অন রাখুন। এই অ্যাপের শব্দ কলের অপর পাশে যাবে।", 13, Color.parseColor("#9a9ea8"), Gravity.CENTER);

        startBtn = button("🎙️ মাইক চালু করুন", Color.parseColor("#22c3a6"));
        startBtn.setOnClickListener(v -> {
            if (AudioService.running) {
                stopService(new Intent(this, AudioService.class));
                AudioService.running = false;
                refresh();
            } else {
                askPermsAndStart();
            }
        });

        button("🎵 গান যোগ করুন", Color.parseColor("#7c5cff")).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/*");
            startActivityForResult(i, REQ_SONG);
        });

        playBtn = button("▶ গান চালান / থামান", Color.parseColor("#23262f"));
        playBtn.setOnClickListener(v -> {
            if (AudioService.mp == null) {
                Toast.makeText(this, "আগে গান যোগ করুন", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean p = AudioService.toggleMusic();
            playBtn.setText(p ? "⏸ গান থামান" : "▶ গান চালান");
        });

        status = text("মাইক বন্ধ আছে", 13, Color.parseColor("#9a9ea8"), Gravity.CENTER);

        text("আপনার গলা", 15, Color.WHITE, Gravity.START);
        bar("মাইক ভলিউম", 300, 100, v -> AudioService.micGain = v / 100f);
        text("ইকো", 15, Color.WHITE, Gravity.START);
        bar("ইকো মাত্রা", 100, 35, v -> AudioService.echoMix = v / 100f);
        bar("ইকো দেরি (ms)", 600, 250, v -> AudioService.echoSec = Math.max(50, v) / 1000f);
        bar("ইকো রিপিট", 80, 30, v -> AudioService.echoFb = v / 100f);
        text("মিউজিক", 15, Color.WHITE, Gravity.START);
        bar("মিউজিক ভলিউম", 100, 80, v -> { AudioService.musicVol = v / 100f; AudioService.applyMusicVol(); });

        text("টিপস: মাইক চালু করে গান প্লে করুন, তারপর মেসেঞ্জার কলে স্পিকার অন করুন। এই অ্যাপ খোলা রাখুন, বন্ধ করবেন না। শব্দ ফিডব্যাক হলে (চিঁ চিঁ) মাইক ভলিউম কমান।", 12, Color.parseColor("#9a9ea8"), Gravity.START);
        refresh();
    }

    TextView text(String s, int sp, int color, int grav) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color); t.setGravity(grav);
        t.setPadding(0, dp(8), 0, dp(4));
        root.addView(t);
        return t;
    }

    Button button(String s, int color) {
        Button bt = new Button(this);
        bt.setText(s); bt.setTextColor(Color.WHITE); bt.setBackgroundColor(color);
        bt.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
        lp.topMargin = dp(10);
        bt.setLayoutParams(lp);
        root.addView(bt);
        return bt;
    }

    void bar(String label, int max, int init, IntConsumer cb) {
        TextView t = text(label + ": " + init, 13, Color.parseColor("#cfd2d8"), Gravity.START);
        SeekBar sb = new SeekBar(this);
        sb.setMax(max);
        sb.setProgress(init);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                t.setText(label + ": " + p);
                cb.accept(p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        cb.accept(init);
        root.addView(sb);
    }

    void refresh() {
        boolean on = AudioService.running;
        startBtn.setText(on ? "⏹ মাইক বন্ধ করুন" : "🎙️ মাইক চালু করুন");
        startBtn.setBackgroundColor(Color.parseColor(on ? "#ff5c5c" : "#22c3a6"));
        status.setText(on ? "মাইক চালু আছে" : "মাইক বন্ধ আছে");
    }

    void askPermsAndStart() {
        java.util.ArrayList<String> need = new java.util.ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (need.isEmpty()) startEngine();
        else requestPermissions(need.toArray(new String[0]), REQ_PERM);
    }

    @Override public void onRequestPermissionsResult(int code, String[] p, int[] r) {
        super.onRequestPermissionsResult(code, p, r);
        if (code == REQ_PERM) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startEngine();
            else Toast.makeText(this, "মাইকের পারমিশন দিতে হবে", Toast.LENGTH_LONG).show();
        }
    }

    void startEngine() {
        startForegroundService(new Intent(this, AudioService.class));
        status.setText("মাইক চালু হচ্ছে...");
        h.postDelayed(this::refresh, 600);
    }

    @Override protected void onActivityResult(int code, int res, Intent data) {
        super.onActivityResult(code, res, data);
        if (code == REQ_SONG && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try {
                AudioService.loadMusic(this, u);
                status.setText("গান যোগ হয়েছে ✔ — এখন \"গান চালান\" চাপুন");
                playBtn.setText("▶ গান চালান");
            } catch (Exception e) {
                status.setText("গান লোড হয়নি: " + e.getMessage());
            }
        }
    }

    @Override protected void onResume() { super.onResume(); if (startBtn != null) refresh(); }
}
